import pandas as pd
df = pd.read_csv('data/curated_smiles.csv')
print(df)

